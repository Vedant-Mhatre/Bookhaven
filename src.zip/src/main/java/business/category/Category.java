
package business.category;

public record Category(long categoryId, String name) {}
